package com.pack;

import org.hibernate.HibernateException;
 
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
 
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.*;

import javax.persistence.TypedQuery;


public class Main {

	public static void main(String[] args) {
		 SessionFactory factory=HibernateUtil.getSessionFactory();
		    Session session=factory.openSession(); 
try {
   

	 
	       Transaction  transaction = null;
	 
			transaction = session.beginTransaction();
			
			Address address1=new Address();
			address1.setStreet("OTR Road");
			address1.setCity("Chennai");
			address1.setState("Tamil Nadu");
			address1.setZipcode("60087");
			
			Set<Student> hs=new HashSet<Student>();
			
			
			Student student1=new Student();
			Student student2=new Student();
			
					
		    student1.setStudentName("priya");
		    student2.setStudentName("Arthy");
		    
		    student1.setStudentAddress(address1);
		    student2.setStudentAddress(address1);
		    
		    hs.add(student1);
			hs.add(student2);
			
			address1.setPeople(hs);
			
		 	session.save(student1);
		 	session.save(student2);
		 
			transaction.commit();
			System.out.println("Object Student1's city");
			
			System.out.println(student1.getStudentAddress().getCity());
			
			 
			
			System.out.println("Students who belong to address1 object");
			
			Set s1=address1.getPeople();
			
				for (Iterator itr=s1.iterator();itr.hasNext();)
				{
	 		         Student S=(Student)itr.next();
			         System.out.println(S.getStudentName());
				}
			
			
				 TypedQuery query = session.getNamedQuery("findByName");    
		            query.setParameter("name", "Joe");   
			 
				 
				    List<Long>  list= query.getResultList();
			   
				    Iterator<Long> itr=list.iterator();
			    	
			    	 while (itr.hasNext())
			    	 {
				       Long id = (Long) itr.next();
				       System.out.println("Id: " + id);
				  //     System.out.println("City: " + row[1]);
				     
				     }	 
		} catch (HibernateException e) {
		 
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
