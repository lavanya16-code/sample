package com.pack;

import java.util.Iterator;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
 
 
//Many students having the same address




public class Main {

	public static void main(String[] args) {

		  Session session=null;
		  Transaction transaction = null;
			 
	try {
		  SessionFactory factory=HibernateUtil.getSessionFactory();
		    session=factory.openSession(); 
	     
			transaction = session.beginTransaction();
			Address address = new Address("OMR Road", "Chennai", "TN", "60097");
			
			Student student1 = new Student("Eswar", address);
			Student student2 = new Student("Joe", address);
			session.save(student1);
			session.save(student2);
			student1.getStudentAddress().getCity();
		 
			transaction.commit();
	        
			
			
			
		} catch(HibernateException e)
		{
			  
		    e.printStackTrace();
		} 
		finally
		{
			 session.close();
		}
	}

}
